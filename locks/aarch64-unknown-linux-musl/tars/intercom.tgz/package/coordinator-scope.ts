/** Ambient Intercom is reserved for top-level coordinators. */
export function isCoordinatorSession(env: NodeJS.ProcessEnv = process.env): boolean {
  return env.PI_SUBAGENT_CHILD !== "1"
    && env.USR_SCOPED_WORKER !== "1"
    && env.USR_REQUIRED_CHILD_EXTENSIONS_JSON === undefined;
}
