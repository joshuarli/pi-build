import { chmodSync, mkdirSync } from "fs";
import { isAbsolute, join, resolve } from "path";
import { homedir } from "os";
import { getRemoteBrokerConnectTarget } from "./remote-transport.ts";
export { getRemoteBrokerListenTarget, isRemoteBrokerConfigured } from "./remote-transport.ts";

export const INTERCOM_DIR_MODE = 0o700;
export const INTERCOM_RUNTIME_FILE_MODE = 0o600;
export const INTERCOM_PROTOCOL_NAME = "pi-intercom";
export const INTERCOM_PROTOCOL_VERSION = 3;

export type BrokerConnectTarget = string | { transport: "tcp"; host: string; port: number };

export function getAgentDirPath(
  env: NodeJS.ProcessEnv = process.env,
  homeDir: string = homedir(),
  cwd: string = process.cwd(),
): string {
  const configured = env.PI_CODING_AGENT_DIR?.trim();
  if (!configured) {
    return join(homeDir, ".pi/agent");
  }

  return isAbsolute(configured) ? configured : resolve(cwd, configured);
}

export function getIntercomDirPath(agentDir: string = getAgentDirPath()): string {
  return join(agentDir, "intercom");
}

export function getBrokerAskStateFilePath(intercomDir: string = getIntercomDirPath()): string {
  return join(intercomDir, "broker-asks.json");
}

export function getBrokerAccessStateFilePath(intercomDir: string = getIntercomDirPath()): string {
  return join(intercomDir, "broker-access.json");
}

export function getBrokerAdminCredentialFilePath(intercomDir: string = getIntercomDirPath()): string {
  return join(intercomDir, "broker-admin.json");
}

export function getBrokerAuditFilePath(intercomDir: string = getIntercomDirPath()): string {
  return join(intercomDir, "broker-audit.jsonl");
}

export function getRemoteGatewaySocketPath(agentDir: string = getAgentDirPath()): string {
  return join(getIntercomDirPath(agentDir), "remote-gateway.sock");
}

export function getBrokerSocketPath(
  agentDir: string = getAgentDirPath(),
): string {
  return join(getIntercomDirPath(agentDir), "broker.sock");
}

export function getBrokerConnectTarget(
  env: NodeJS.ProcessEnv = process.env,
): BrokerConnectTarget {
  const remote = getRemoteBrokerConnectTarget(env);
  if (remote !== undefined) return remote;
  return getBrokerSocketPath(getAgentDirPath(env));
}

export function getBrokerListenTarget(): string {
  return getBrokerSocketPath(getAgentDirPath());
}

export function ensureIntercomRuntimeDir(
  intercomDir: string = getIntercomDirPath(),
): void {
  mkdirSync(intercomDir, { recursive: true, mode: INTERCOM_DIR_MODE });
  chmodSync(intercomDir, INTERCOM_DIR_MODE);
}

export function restrictIntercomRuntimeFile(
  filePath: string,
): void {
  chmodSync(filePath, INTERCOM_RUNTIME_FILE_MODE);
}
