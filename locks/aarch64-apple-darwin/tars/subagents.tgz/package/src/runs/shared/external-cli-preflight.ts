import { spawnSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";

const MAX_PROBE_OUTPUT_BYTES = 256 * 1024;
const MAX_PROBE_TIMEOUT_MS = 5_000;
const MAX_REMOTE_PROBE_TIMEOUT_MS = 15_000;
const MAX_CACHE_ENTRIES = 64;
const MAX_AVAILABILITY_REASON_LENGTH = 256;

export type ExternalCliPreflightInvalidationReason = "launch" | "auth" | "parser" | "permission";

export interface ExternalCliPreflightSpec {
	id: string;
	versionArgs: readonly string[];
	helpArgs: readonly string[];
	evidenceArgs?: readonly string[];
	evidenceLabel?: string;
	probeTimeoutMs?: number;
	/** Remote probes include SSH handshakes; values may only narrow the code-owned remote ceiling. */
	remote?: boolean;
	validate?: (result: ExternalCliPreflightResult) => void;
}

export interface ExternalCliPreflightResult {
	binaryPath: string;
	binaryMtimeMs: number;
	version: string;
	help: string;
	evidence?: string;
	cacheHit: boolean;
}

type CachedPreflight = Omit<ExternalCliPreflightResult, "cacheHit">;

const cache = new Map<string, CachedPreflight>();
const lookup = new Map<string, string>();

export type ExternalCliBinaryAvailability =
	| { available: true }
	| { available: false; unavailableReason: string };

function resolveBinary(command: string, env: NodeJS.ProcessEnv): string {
	if (path.isAbsolute(command) || command.includes(path.sep)) {
		const resolved = path.resolve(command);
		fs.accessSync(resolved, fs.constants.X_OK);
		return resolved;
	}
	for (const directory of (env.PATH ?? "").split(path.delimiter)) {
		if (!directory) continue;
		const candidate = path.join(directory, command);
		try {
			fs.accessSync(candidate, fs.constants.X_OK);
			return fs.realpathSync(candidate);
		} catch {}
	}
	throw new Error(`External CLI binary '${command}' was not found on PATH.`);
}

/** Resolve only the configured command; unlike preflight, this never starts a child process. */
export function resolveExternalCliBinaryAvailability(command: string, env: NodeJS.ProcessEnv): ExternalCliBinaryAvailability {
	try {
		resolveBinary(command, env);
		return { available: true };
	} catch (error) {
		const reason = error instanceof Error ? error.message : String(error);
		return { available: false, unavailableReason: reason.slice(0, MAX_AVAILABILITY_REASON_LENGTH) };
	}
}

export interface ExternalCliSpawn {
	command: string;
	args: readonly string[];
}

function probeWithTimeout(binaryPath: string, args: readonly string[], env: NodeJS.ProcessEnv, label: string, timeoutMs: number, cwd?: string): string {
	const result = spawnSync(binaryPath, args, {
		cwd,
		env,
		encoding: "utf-8",
		killSignal: "SIGKILL",
		maxBuffer: MAX_PROBE_OUTPUT_BYTES,
		timeout: timeoutMs,
	});
	if (result.error) throw new Error(`External CLI ${label} preflight failed: ${result.error.message}`, { cause: result.error });
	if (result.status !== 0) throw new Error(`External CLI ${label} preflight exited with code ${result.status}: ${(result.stderr || result.stdout).trim()}`);
	return result.stdout.trim();
}

function narrowPositiveInteger(value: number | undefined, ceiling: number, label: string): number {
	if (value === undefined) return ceiling;
	if (!Number.isSafeInteger(value) || value <= 0 || value > ceiling) throw new Error(`${label} may only narrow the code-owned ceiling of ${ceiling}.`);
	return value;
}

function specKey(spec: ExternalCliPreflightSpec): string {
	return JSON.stringify([spec.id, spec.versionArgs, spec.helpArgs, spec.evidenceArgs, spec.evidenceLabel, spec.probeTimeoutMs, spec.remote === true]);
}

export function preflightExternalCli(command: string, spec: ExternalCliPreflightSpec, env: NodeJS.ProcessEnv, cwd?: string): ExternalCliPreflightResult {
	const binaryPath = resolveBinary(command, env);
	const binaryMtimeMs = fs.statSync(binaryPath).mtimeMs;
	const lookupKey = JSON.stringify([binaryPath, binaryMtimeMs, specKey(spec)]);
	const cachedKey = lookup.get(lookupKey);
	const cached = cachedKey ? cache.get(cachedKey) : undefined;
	const ceiling = spec.remote === true ? MAX_REMOTE_PROBE_TIMEOUT_MS : MAX_PROBE_TIMEOUT_MS;
	const probeTimeoutMs = narrowPositiveInteger(spec.probeTimeoutMs, ceiling, "probeTimeoutMs");
	const base = cached ?? {
		binaryPath,
		binaryMtimeMs,
		version: probeWithTimeout(binaryPath, spec.versionArgs, env, "version", probeTimeoutMs, cwd),
		help: probeWithTimeout(binaryPath, spec.helpArgs, env, "help", probeTimeoutMs, cwd),
	};
	const evidence = spec.evidenceArgs
		? probeWithTimeout(binaryPath, spec.evidenceArgs, env, spec.evidenceLabel ?? "evidence", probeTimeoutMs, cwd)
		: undefined;
	const result = { ...base, ...(evidence !== undefined ? { evidence } : {}), cacheHit: Boolean(cached) };
	spec.validate?.(result);
	if (!cached) {
		const cacheKey = JSON.stringify([binaryPath, base.version, binaryMtimeMs, specKey(spec)]);
		cache.set(cacheKey, base);
		lookup.set(lookupKey, cacheKey);
		while (cache.size > MAX_CACHE_ENTRIES) {
			const oldest = cache.keys().next().value as string;
			cache.delete(oldest);
			for (const [candidateLookup, candidateCache] of lookup) if (candidateCache === oldest) lookup.delete(candidateLookup);
		}
	}
	return result;
}

export function invalidateExternalCliPreflight(command: string, spec: ExternalCliPreflightSpec, _reason: ExternalCliPreflightInvalidationReason): void {
	const key = specKey(spec);
	for (const [cacheKey, entry] of cache) {
		if (entry.binaryPath === command || entry.binaryPath.endsWith(`${path.sep}${command}`) || cacheKey.includes(key)) cache.delete(cacheKey);
	}
	for (const [lookupKey, cacheKey] of lookup) if (!cache.has(cacheKey)) lookup.delete(lookupKey);
}

export function clearExternalCliPreflightCacheForTests(): void {
	cache.clear();
	lookup.clear();
}
