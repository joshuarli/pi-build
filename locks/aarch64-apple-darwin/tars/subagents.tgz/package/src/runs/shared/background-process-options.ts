export function backgroundProcessOptions(): {
	detached: boolean;
} {
	return {
		detached: true,
	};
}
