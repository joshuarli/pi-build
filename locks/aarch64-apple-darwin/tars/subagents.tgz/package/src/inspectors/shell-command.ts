function shellQuote(value: string): string {
	return `'${value.replaceAll("'", "'\\''")}'`;
}

function isBareExecutable(value: string): boolean {
	return /^[\w./@:-]+$/.test(value);
}

export function formatShellCommand(exe: string, args: readonly string[]): string {
	const quotedArgs = args.map(shellQuote);
	// Nushell treats a leading quoted token as a string, so use a bare invoker for paths that need quoting.
	const invocation = isBareExecutable(exe) ? exe : `sh -c 'exec "$0" "$@"' ${shellQuote(exe)}`;
	return [invocation, ...quotedArgs].join(" ");
}
