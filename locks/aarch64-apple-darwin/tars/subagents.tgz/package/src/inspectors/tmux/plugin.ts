import { closeTmuxInspector, openTmuxInspector, readTmuxInspectorBindingForTarget, statusTmuxInspector } from "./actions.ts";
import { createTmuxClient, type TmuxClient } from "./client.ts";
import type { InspectorPlugin } from "../types.ts";

export interface TmuxPluginDeps {
	client?: TmuxClient;
}

export function createTmuxInspectorPlugin(deps: TmuxPluginDeps = {}): InspectorPlugin {
	const client = deps.client ?? createTmuxClient();
	return {
		name: "tmux",
		available: (context) => Boolean(context.env.TMUX),
		owns: (context) => readTmuxInspectorBindingForTarget(context.target) !== undefined,
		open: (context, launch, params) => openTmuxInspector(context, launch, params.focus === true, client),
		status: (context) => statusTmuxInspector(context, client),
		close: (context) => closeTmuxInspector(context, client),
	};
}
