import { execFile } from "node:child_process";
import { promises as fs } from "node:fs";

/** Optional global package discovery; a failure never prevents local discovery. */
export async function resolveGlobalNpmRoot(options: {
	env?: NodeJS.ProcessEnv;
	timeoutMs?: number;
	signal?: AbortSignal;
} = {}): Promise<string | null> {
	const signal = options.signal;
	if (signal?.aborted) return null;
	const env = options.env ?? process.env;
	const offline = env.PI_OFFLINE?.toLowerCase();
	if (offline === "1" || offline === "true" || offline === "yes") return null;

	if (signal?.aborted) return null;
	const timeoutMs = options.timeoutMs ?? 5000;
	const output = await new Promise<string | null>((resolve) => {
		let settled = false;
		const finish = (value: string | null) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			signal?.removeEventListener("abort", cancel);
			resolve(value);
		};
		const commandOptions = {
			encoding: "utf8",
			timeout: timeoutMs,
			env,
			maxBuffer: 64 * 1024,
		} as const;
		// POSIX npm is executable directly: killing a shell would leave npm running.
		const callback = (error: Error | null, stdout: string) => finish(error ? null : stdout.trim());
		const child = execFile("npm", ["root", "-g"], commandOptions, callback);
		const cancel = () => {
			child.kill();
			finish(null);
		};
		// Resolve at the deadline even if inherited pipes hold the callback open.
		const timer = setTimeout(cancel, timeoutMs);
		signal?.addEventListener("abort", cancel, { once: true });
	});
	if (!output) return null;
	try {
		return await fs.realpath(output);
	} catch {
		return null;
	}
}
