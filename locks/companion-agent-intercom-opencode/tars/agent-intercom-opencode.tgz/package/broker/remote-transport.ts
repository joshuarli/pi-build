import { isIP } from "node:net";
import { isAbsolute } from "node:path";
import { closeSync, constants, fstatSync, openSync, readFileSync } from "node:fs";

export interface RemoteTcpTarget {
  transport: "tcp";
  host: string;
  port: number;
}

export type RemoteBrokerTarget = string | RemoteTcpTarget;

const ENDPOINT_ENV = "AGENT_INTERCOM_REMOTE_ENDPOINT";
const CREDENTIAL_ENV = "AGENT_INTERCOM_ACCESS_CREDENTIAL_PATH";
const LISTEN_ENV = "AGENT_INTERCOM_REMOTE_LISTEN";

export function isRemoteBrokerConfigured(env: NodeJS.ProcessEnv = process.env): boolean {
  // An explicitly empty value is a configuration error, never local fallback.
  return env[ENDPOINT_ENV] !== undefined;
}

function isTailnetAddress(host: string): boolean {
  if (isIP(host) === 4) {
    const bytes = host.split(".").map(Number);
    return bytes[0] === 100 && bytes[1] >= 64 && bytes[1] <= 127;
  }
  return isIP(host) === 6 && /^fd7a:115c:a1e0:/i.test(host);
}

export function parseRemoteBrokerTarget(value: string, setting = ENDPOINT_ENV): RemoteBrokerTarget {
  if (!value || value !== value.trim() || /[\u0000-\u0020\u007f]/.test(value)) {
    throw new Error(`${setting} must be a nonempty endpoint without whitespace`);
  }
  let endpoint: URL;
  try {
    endpoint = new URL(value);
  } catch {
    throw new Error(`${setting} must be tcp://<tailnet-IP>:<port> or unix:///absolute/socket`);
  }
  if (endpoint.username || endpoint.password || endpoint.search || endpoint.hash) {
    throw new Error(`${setting} cannot contain credentials, query parameters, or fragments`);
  }
  if (endpoint.protocol === "unix:") {
    if (!value.startsWith("unix:///") || endpoint.host) {
      throw new Error(`${setting} requires an absolute Unix socket path`);
    }
    let path: string;
    try {
      path = decodeURIComponent(endpoint.pathname);
    } catch {
      throw new Error(`${setting} contains an invalid encoded socket path`);
    }
    if (!isAbsolute(path) || path === "/" || path.endsWith("/") || /[\u0000-\u001f\u007f]/.test(path)) {
      throw new Error(`${setting} requires an absolute Unix socket file path`);
    }
    return path;
  }
  const host = endpoint.hostname.replace(/^\[|\]$/g, "");
  const port = Number(endpoint.port);
  if (endpoint.protocol !== "tcp:" || endpoint.pathname || !isTailnetAddress(host)
      || !/^[0-9]+$/.test(endpoint.port) || !Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`${setting} must use a literal Tailscale 100.64.0.0/10 or fd7a:115c:a1e0::/48 address and port 1–65535`);
  }
  return { transport: "tcp", host, port };
}

export function getRemoteBrokerConnectTarget(env: NodeJS.ProcessEnv = process.env): RemoteBrokerTarget | undefined {
  if (!isRemoteBrokerConfigured(env)) {
    if (env[CREDENTIAL_ENV] !== undefined) {
      throw new Error(`${CREDENTIAL_ENV} requires ${ENDPOINT_ENV}; refusing local fallback`);
    }
    return undefined;
  }
  const path = env[CREDENTIAL_ENV];
  if (!path || path !== path.trim() || !isAbsolute(path) || path.includes("\0")) {
    throw new Error(`${ENDPOINT_ENV} requires an absolute ${CREDENTIAL_ENV}`);
  }
  return parseRemoteBrokerTarget(env[ENDPOINT_ENV]!, ENDPOINT_ENV);
}

export function getRemoteBrokerListenTarget(env: NodeJS.ProcessEnv = process.env): RemoteBrokerTarget | undefined {
  if (env[LISTEN_ENV] === undefined) return undefined;
  if (isRemoteBrokerConfigured(env)) {
    throw new Error(`${LISTEN_ENV} and ${ENDPOINT_ENV} cannot be enabled in the same process`);
  }
  return parseRemoteBrokerTarget(env[LISTEN_ENV]!, LISTEN_ENV);
}

export function readRemoteCredential(path: string): string {
  const fd = openSync(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || stat.size > 65536) throw new Error("Remote credential must be a regular file no larger than 64 KiB");
    if ((stat.mode & 0o077) !== 0
        || (typeof process.getuid === "function" && stat.uid !== process.getuid())) {
      throw new Error("Remote credential must be owned by the current user with mode 0600 or stricter");
    }
    return readFileSync(fd, "utf8");
  } finally {
    closeSync(fd);
  }
}
